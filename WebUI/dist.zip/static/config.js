window.apiObj = {
  // 没事不建议乱加斜杠
    apiUrl:'https://test.ddtv.pro:11419',

    //参考格式：[https://你的域名:11419]或者[http://你的域名:11419]
  }